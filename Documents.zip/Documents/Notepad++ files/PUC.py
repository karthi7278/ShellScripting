With unclean.leader.election.enable=true, Kafka will allow some replica of a partition which is not in ISR to become leader if no replica in ISR is available.
 With the property set to false, only a replica which is in ISR will become leader. 
 If no such replica is available, the partition will become unavailable.

Electing a replica which is not part of the ISR can result in data loss, so setting the property to true can result in data loss.

Please see the following for details on the trade offs between setting this property to true or false:
https://docs.hortonworks.com/HDPDocuments/HDP2/HDP-2.6.5/bk_kafka-component-guide/content/kafka-broker-settings.html

Let me know if you have any additional questions. Also, please let me know is the scenario which you describe the root cause of your Spark job failure?
 If you still need assistance with troubleshooting that job, please provide the information we have requested previously.
 
 ERROR Java::OrgApacheHadoopHbaseIpc::RemoteWithExtrasException: 
 org.apache.hadoop.hbase.coprocessor.CoprocessorException: javax.net.ssl.SSLHandshakeException: sun.security.validator.ValidatorException: 
 No trusted certificate found