package com.esi.dpe.pt.validation

import java.io.File
import java.util.Date
import io.Source

case class TableInfo(tableName:String, primaryKey: String, otherColumns:String,fallBackHrs:Option[String],setOffMins : String
                       sample: Option[Int], maxRows: Option[Int], timestampColumn: Option[Date],srcJoinColumn: Option[String], joinTable:Option[JoinInfo],
					   dateRange:Option[DateRange], tgtJoinColumn:Option[String],comments: Option[String])
					   
case class JoinInfo(joinColumn:String, joinTable:String, joinTableColumn:String)
case class DateRange(beginTime: Date, endTime:Date)

case class LocationInfo(pharmacyLocation:String, dbUrl:String, dbUser:String,dbClass: Option[String],user: Option[String],Pass: Option[String],basePath: Option[String])

object DataValidator {

  
  def main(args: Array[String]): Unit = {
    /**
      * 1. Get location as an argument
      * 2. Get the table configuration file as argument
      * 3. Get the location configuration as an argument
      * 4. Read Config and use that to build List of TableInfo and Map<locationCode, LocationInfo>
      * 5. For each table, call validate Method below
      *
      */
	  
	  val spark = SparkSession.builder().appName("compaction").enableHiveSupport().getOrCreate()
	  val conf = new SparkConf().setAppName("Incremental").setMaster("YARN")
      val sc   = new SparkContext(conf)
  
	  val tableInfo = ""
	  val locationInfo = ""
	  JoinTable joinTable = new JoinTable()

	  val tableFile = Source.fromFile("/user/bhanu/TableInfo.csv")
		for(line <- tableFile.getLines) {
		val tcols = line.split(",").map(_.trim)
		 tableInfo = new TableInfo("tcols(0)","tcols(1)","tcols(2)","tcols(3)","tcols(4)",tcols(5),tcols(6),tcols(7),"tcols(8)",tcols(9),tcols(10),"tcols(11)","tcols(12)")
		}
		tableFile.close
		
		val locationFile = sc.textFile("/user/bhanu/LocationInfo.csv")
		for(line <- locationFile.getLines) {
		val lcols = line.split(",").map(_.trim)
		locationInfo = new LocationInfo("lcols(0)","lcols(1)","lcols(2)","lcols(3)","lcols(4)","lcols(5)","lcols(6)")
		}
		locationFile.close
	  
	  
	  hoursBetween = tableInfo.fallBackHrs.toInt
	  DataValidator dataValidator = new DataValidator()
	  dataValidator.validateTable(tableInfo(1),locationId)
	 
  }

  def validateTable (tableInfo: TableInfo, locationInfo: LocationInfo) = {
    /**
      * 1. Call OracleDataExtractor to get a Data Frame
      * 2. Call PTHdfsDataExtractor to get the Data Frame of data from Hdfs.
      * 3. Key the DataFrames by primary key.
      * 4. Join and determine primary keys in Oracle that are not in Hdfs.
      * 5. Write that information to Hive.
      */
	  HDFS_extract pathDF = new HDFS_extract()
	  OracleDataExtractor oracleDataExtractor = new OracleDataExtractor()
	  String HDFSPath = pathDF.pathGenerator(tableInfo,locationInfo)
	  	  
	  var hdfsDF = ""
	  var oracleDF = ""
	  
	   hdfsDF = pathDF.extractData(HDFSPath,tableInfo)
	  }
	  oracleDF = oracleDataExtractor.extract(spark,locationInfo,tableInfo)
	  
	  hdfsDF.registerTempTable("hdfsTable")
	  oracleDF.registerTempTable("oracleTable")
	  
	  var result = spark.sql("create table CompareTable as select h.*,o.* from hdfsTable h left join oracleTable o on h.primaryKey = o.primaryKey")

	  }

  }

  def readTableConfig (fileName:String ): List[TableInfo] ={

  }

  def readLocationInfo (fileName:String) : Map[String, LocationInfo] = {
	  
	   

  }

}
