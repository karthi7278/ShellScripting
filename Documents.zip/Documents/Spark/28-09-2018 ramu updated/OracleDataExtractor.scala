package com.esi.dpe.pt.validation

import org.apache.hadoop.conf.Configuration
import org.apache.spark.sql.{DataFrame, SparkSession}

object OracleDataExtractor {

  /**
    * Create a <code>DataFrame</code> by reading from Oracle using the parameters provided.
    *
    * <ul>
    *    <li>If incremental column is provided in the <code<TableInfo</code>, an incremental query will be built using the date range provided.
    *    <li>If sample percentage is provided, only a sample of the data will be retrieved.</li>
    *    <li>If joinInfo is provided, it will be used to join to a different table to build the incremental extract.
    * </ul>
    *
    * @param hdpConfig the Hadoop Config to use to retrieve the data base connection password.
    * @param locationInfo the configuration about the pharmacy Location
    * @param tableInfo the table configuration.
    * @return
    */
	
  Logger.getLogger("org").setLevel(Level.ERROR)
  
		 var conf = new SparkConf().setAppName("Read CSV File").setMaster("local[*]")
		   val sc = new SparkContext(conf)  //Creating SparkContext
	 var calendar = Calendar.getInstance()
		  val sdf = new SimpleDateFormat("yyyy-MM-dd:hh:mm")
		  var qry = ""
  
  def minsAgo(mins: Int): String = {
      calendar.add(Calendar.MINUTE, -mins)
      sdf.format(calendar.getTime())
  }
  
   def hoursAgo(hours: Int): String = {
      calendar.add(Calendar.HOUR_OF_DAY, -hours)
      sdf.format(calendar.getTime())
  }
   
  def today(): String = {
    val calender = Calendar.getInstance()
    sdf.format(calender.getTime())
  }
  def extract(spark: SparkSession,
              locationInfo: LocationInfo,
              tableInfo: TableInfo): DataFrame = {

    /**
      * 1. Get password for the table.. Create a separate method to call the credential provider to get the password
      * 2. buildQuery
      * 3. Call spark.read to get the DataFrame from Oracle.
      * 4.. Add pharmacy_location to the data frame.S
      */
	 	   
	  OracleDataExtractor oracleDataExtractor = new OracleDataExtractor()
	  var oracleData = oracleDataExtractor.buildQuery(tableInfo)
	  val oracle_RDD = spark.sql(oracleData)
	  
  }

  def buildQuery(tableConfig: TableInfo): String = {

    /**
      * 1. If incremental column is not present, the query would be: select ${tableConfig.cols} from ${tableConfig.tableName}
      * 2. If incremental column is present, we need to build the query using the date range and the join info..
      *    -- Some cases a date column is not present in the table being read. In that case, we need to join to another table
      *       using JoinInfo and build the query. In the case where we are joining we need to handle name conflicts in columns.
      *
      * Example:
      * select a.host_rx_id, a.host_order_id, a.requested_qty
      * from host_rx a, host_order ho
      * where a.host_rx_id = ho.host_order_id and a.received_date between (? , ?)
      *
      * 3. If sample % is provided, we need to use that to sample rows. Need to add sample (?) to the query
      * 4. If maxRecs is provided add that to the query  using something like ROWNUM < ${maxRecs}
      *
      */
					   
          //var location         = row.mkString(",").split(",")(0)
          var table_name       = tableConfig.tableName
          var Columns          = tableConfig.otherColumns
          var condition_col    = tableConfig.joiningTable.joinColumn
          var fall_back_hrs    = tableConfig.fallBackHrs
          var set_off_mins     = tableConfig.setOffMins
          var src_join_column  = tableConfig.srcJoinColumn
          var tgt_join_column  = tableConfig.tgtJoinColumn
          var join_table       = tableConfig.joiningTable.joinTable
          var rec_count        = tableConfig.
          var rec_percent      = tableConfig.
          val endDateHour      = tableConfig.dateRange.endTime
          val startDateHour    = tableConfig.dateRange.startDateHour //hoursBetween
          val startDateHourMin = minsAgo(set_off_mins.toInt)//Minsback
          
          if (condition_col.trim() != "null" && src_join_column.trim() != "null" && tgt_join_column.trim()!= "null" && join_table.trim()!= "null" )
          {
            qry = "select " + Columns + " from " + table_name +" , "+join_table+ " where "+table_name+"." + src_join_column + " = "+join_table+"." + tgt_join_column + " and " +table_name+"." +condition_col +" between  \'"+ startDateHourMin +"\' and \'"+endDateHour +"\' " //
          }
          else if (condition_col.trim()!= "null" && src_join_column.trim() == "null" && tgt_join_column.trim()== "null" && join_table.trim() == "null" )
          {
            qry = "select " + Columns + " from " + table_name + " where " + condition_col +" between  \'"+ startDateHourMin +"\' and \'"+endDateHour +"\' " //
          }
          else if (condition_col.trim()== "null" && src_join_column.trim()== "null" && tgt_join_column.trim()== "null" && join_table.trim()== "null")
          {
            qry = "select " + Columns + " from " + table_name
          }
          
          if ( qry.indexOf("where") >=0){
            if(rec_count!="null" && rec_count.toInt>=0){
              qry=qry+ " and rownum<="+rec_count
            } else if(rec_percent!="null" && rec_percent.toInt>=0) {
              qry=qry+ " and sample("+rec_percent +")"
            } 
          }else {
             if(rec_count!="null" && rec_count.toInt>=0){
              qry=qry+ " where rownum<="+rec_count
            } else if(rec_percent!="null" && rec_percent.toInt>=0) {
              qry=qry+ " where sample("+rec_percent +")"
            }             
          } 
  }
}
