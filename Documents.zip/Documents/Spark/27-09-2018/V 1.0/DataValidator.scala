package com.esi.dpe.pt.validation

import java.io.File
import java.util.Date

case class TableInfo(tableName:String, primaryKey: String, columns:String,
                       samplePercent: Option[Int], maxRecs: Int, dateRange:Option[DateRange],  incrementalColumn:Option[String], joinTable:Option[JoinInfo])

case class JoinInfo(joinColumn:String, joinTable:String, joinTableColumn:String)
case class DateRange(beginTime: Date, endTime:Date)
case class LocationInfo(locationCode:String, locationName:String, databaseUrl:String, databaseUser:String)

object DataValidator {

 var hoursBetween = 25

  def main(args: Array[String]): Unit = {
    /**
      * 1. Get location as an argument
      * 2. Get the table configuration file as argument
      * 3. Get the location configuration as an argument
      * 4. Read Config and use that to build List of TableInfo and Map<locationCode, LocationInfo>
      * 5. For each table, call validate Method below
      *
      */
	  
	  HDFS_extract_bhanu location= new HDFS_extract_bhanu()
	  
	  println("Getting the location :" + location.path)
  }

  def validateTable (tableInfo: TableInfo, locationInfo: LocationInfo) = {
    /**
      * 1. Call OracleDataExtractor to get a Data Frame
      * 2. Call PTHdfsDataExtractor to get the Data Frame of data from Hdfs.
      * 3. Key the DataFrames by primary key.
      * 4. Join and determine primary keys in Oracle that are not in Hdfs.
      * 5. Write that information to Hive.
      */
	  
	  
	  HDFS_extract_bhanu pathDF = new HDFS_extract_bhanu()
	  String path = pathDF.pathGenerator(hoursBetween)
	  var hdfsDF = pathDF.extractData(path)
	  OracleDataExtractor oracleData = new OracleDataExtractor()
	  oracleData.buildQuery

  }

  def readTableConfig (fileName:String ): List[TableInfo] ={

  }

  def readLocationInfo (fileName:String) : Map[String, LocationInfo] = {

  }

}
