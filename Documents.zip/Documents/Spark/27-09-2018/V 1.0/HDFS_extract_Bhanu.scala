package com.esi.spark.hdfscompaction
  
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.{Calendar, Date}
import java.text.SimpleDateFormat
import java.text.CalendarBuilder
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf

class HDFS_extract_bhanu {
  
//global variable declaration
  val conf = new SparkConf().setAppName("Incremental").setMaster("YARN")
  val sc   = new SparkContext(conf)
  var hoursBetween = 25
  val BASEPATH     = "/datahub/pt_rpt/landing"
  val location     = "56"
  val tableName    = "MGPH.TRK_TRACKING"
  val PATHSEP      = "/"
  val STAR         = "*"
  val calendar     = Calendar.getInstance()
  val sdf          = new SimpleDateFormat("yyyy_MM_dd_HH")
  
   val spark= SparkSession.builder()
               .appName("compaction")
               .config("spark.sql.warehouse.dir",BASEPATH)
               .enableHiveSupport()
               .getOrCreate()
  
 
  // the passing hours are subtracting from current date
  def hoursAgo(hours: Int): String = {
      calendar.add(Calendar.HOUR_OF_DAY, -hours)
      sdf.format(calendar.getTime())
  }
   
  def today(): String = {
    val calender = Calendar.getInstance()
    sdf.format(calender.getTime())
  }

  def pathExists(path: String, sc: SparkContext): Boolean = {
      val conf = sc.hadoopConfiguration
      val fs = FileSystem.get(conf)
      fs.exists(new Path(path))
    }
  
  /*def readJson(path:String,sc:SparkContext): Unit = {
    
    var files = spark.read.format("json").option("InferSchema", true).load(path)
    
    
  }*/

  def pathGenerator(hoursBetween:Int):String ={

  
  val startDateHour = hoursAgo(hoursBetween) //hoursBetween
  val endDateHour   = today()
  val startDate     = sdf.parse(startDateHour)
  var endDate       = sdf.parse(endDateHour)
  
  var path=""
  
  if (hoursBetween == 0){
    
     path = BASEPATH + PATHSEP + tableName + PATHSEP + location + PATHSEP + STAR + PATHSEP + STAR + PATHSEP + STAR + PATHSEP + STAR
    
  }else {
    while(hoursBetween >= 0) {
      calendar.setTime(endDate)
      calendar.add(Calendar.HOUR_OF_DAY,-1)
      hoursBetween -= 1
      var dateHourPath = sdf.format(calendar.getTime())
      path = BASEPATH + PATHSEP + tableName + PATHSEP + location + PATHSEP + dateHourPath.substring(0,10) + PATHSEP + dateHourPath + PATHSEP + STAR + PATHSEP + STAR
      if (!pathExists(path,sc)) {
        val tPath = BASEPATH + PATHSEP + tableName + PATHSEP + location + PATHSEP + dateHourPath.substring(0,10) + "/compact/*/*"
        if(pathExists(tPath,sc)) {
          calendar.add(Calendar.HOUR_OF_DAY,-23)
          dateHourPath = sdf.format(calendar.getTime())
          hoursBetween -= 23  
          path=tPath
        } else {
		        calendar.add(Calendar.HOUR_OF_DAY,-23)
            dateHourPath = sdf.format(calendar.getTime())
            hoursBetween -= 23  
			      path =  BASEPATH + PATHSEP + tableName + PATHSEP + location + PATHSEP + dateHourPath.substring(0,10)+ "/*/*/*"		
	   	}
      }
      println("path :" + path)
      endDate = sdf.parse(dateHourPath)
      //  println("The Date hour path is : "+dateHourPath)
      //println("New end date :" + endDate)
    }
   }
  
  //path generation
  
  }
  
  def extractData(path:String): DataFrame ={
  
  
  }
  

}


       //val finalDate = sdf.format(tempDate)
       
       //if(finalDate.isBefore(startDate)) {
              //path = s"root/level1/level2/$finalDate/*/*/"
       //     println ( path)
       //}//*/
