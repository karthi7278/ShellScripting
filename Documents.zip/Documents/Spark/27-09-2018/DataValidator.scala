package com.esi.dpe.pt.validation

import java.io.File
import java.util.Date

case class TableInfo(tableName:String, primaryKey: String, otherColumns:String,fallBackHrs:Option[String],setOffMins : String
                       sample: Option[Int], maxRows: Option[Int], timestampColumn: Option[Date],srcJoinColumn: Option[String], joinTable:Option[JoinInfo],
					   dateRange:Option[DateRange], tgtJoinColumn:Option[String],comments: Option[String])
					   
//tableName,primaryKey,otherColumns ,fallBackHrs,setOffMins
//optional cols:sample,maxRows,timestampColumn,srcJoinColumn,joinTable,tgtJoinColumn,comments



case class JoinInfo(joinColumn:String, joinTable:String, joinTableColumn:String)
case class DateRange(beginTime: Date, endTime:Date)

//pharmacyLocation,dbUrl,dbUser,dbClass,user,Pass,basePath
case class LocationInfo(pharmacyLocation:String, dbUrl:String, dbUser:String,dbClass: Option[String],user: Option[String],Pass: Option[String],basePath: Option[String])

object DataValidator {

 var hoursBetween = 25

  def main(args: Array[String]): Unit = {
    /**
      * 1. Get location as an argument
      * 2. Get the table configuration file as argument
      * 3. Get the location configuration as an argument
      * 4. Read Config and use that to build List of TableInfo and Map<locationCode, LocationInfo>
      * 5. For each table, call validate Method below
      *
      */
	  val conf = new SparkConf().setAppName("Incremental").setMaster("YARN")
      val sc   = new SparkContext(conf)
	  val baseLocation = sc.textFile("/user/bhanu/LocationInfo.csv")
	  val locationCase = baseLocation.map(a => LocationInfo(a(0).trim(),a(1).trim(),a(2).trim(),a(3).trim(),a(4).trim(),a(5).trim(),a(6).trim()))
	  var locationId = baseLocation(x=>x(0))  //66
	  TableInfo tableInfo = new TableInfo()
	  DataValidator dataValidator = new DataValidator()
	  dataValidator.validateTable(tableInfo(1),locationId)
	 

	 //HDFS_extract_bhanu location= new HDFS_extract_bhanu()	  
	  //println("Getting the location :" + location.path)
  }

  def validateTable (tableInfo: TableInfo, locationInfo: LocationInfo) = {
    /**
      * 1. Call OracleDataExtractor to get a Data Frame
      * 2. Call PTHdfsDataExtractor to get the Data Frame of data from Hdfs.
      * 3. Key the DataFrames by primary key.
      * 4. Join and determine primary keys in Oracle that are not in Hdfs.
      * 5. Write that information to Hive.
      */
	  

	  
	  HDFS_extract_bhanu pathDF = new HDFS_extract_bhanu()
	  String HDFSPath = pathDF.pathGenerator(hoursBetween)
	  var hdfsDF = ""
	  var oracleDF = ""
	  
	  if(HDFS_extract_bhanu.location==locationId) { //66
	   hdfsDF = pathDF.extractData(HDFSPath,tableInfo)
	  }
	  
	  OracleDataExtractor oracleDataExtractor = new OracleDataExtractor()
	  oracleDF = oracleDataExtractor.extract(spark: SparkSession,hdpConfig: Configuration,locationInfo,tableInfo)
	  
	  hdfsDF.registerTempTable("hdfsTable")
	  oracleDF.registerTempTable("oracleTable")
	  
	  var result = spark.sql("create table as select h.*,o.* from hdfsTable h left join oracleTable o on h.primaryKey = o.primaryKey")
	  
//val df =oracleDF.join(hdfsDF,oracleDF.col("primaryKey") ===hdfsDF.col("primaryKey")) 
	  // write comparison logic for oracle and hdfs
	  }
	  
	  for()
	  OracleDataExtractor oracleData = new OracleDataExtractor()
	  oracleData.buildQuery

  }

  def readTableConfig (fileName:String ): List[TableInfo] ={

  }

  def readLocationInfo (fileName:String) : Map[String, LocationInfo] = {

  }

}
