package com.esi.dpe.pt.validation

import org.apache.hadoop.conf.Configuration
import org.apache.spark.sql.{DataFrame, SparkSession}

object OracleDataExtractor {

  /**
    * Create a <code>DataFrame</code> by reading from Oracle using the parameters provided.
    *
    * <ul>
    *    <li>If incremental column is provided in the <code<TableInfo</code>, an incremental query will be built using the date range provided.
    *    <li>If sample percentage is provided, only a sample of the data will be retrieved.</li>
    *    <li>If joinInfo is provided, it will be used to join to a different table to build the incremental extract.
    * </ul>
    *
    * @param hdpConfig the Hadoop Config to use to retrieve the data base connection password.
    * @param locationInfo the configuration about the pharmacy Location
    * @param tableInfo the table configuration.
    * @return
    */
  def extract(spark: SparkSession,
              hdpConfig: Configuration,
              locationInfo: LocationInfo,
              tableInfo: TableInfo): DataFrame = {

    /**
      * 1. Get password for the table.. Create a separate method to call the credential provider to get the password
      * 2. buildQuery
      * 3. Call spark.read to get the DataFrame from Oracle.
      * 4.. Add pharmacy_location to the data frame.S
      */
	  // hdpConfig: Configuration,@ where we are referring it
	 	   
	  OracleDataExtractor oracleDataExtractor = new OracleDataExtractor()
	  val oracleData = oracleDataExtractor.buildQuery(tableInfo) // Assumed it returns a DataFrame
	  val oracle_RDD = oracleData.rdd.map(T => tableInfo(T(0),T(1)),T(2)),T(3)),T(4)),T(5)),T(6)),T(7)),T(8)),T(9)),T(10)),T(11)),T(12)))
	  val oracle_DF = oracle_RDD.toDF()
	  
  }

  def buildQuery(tableConfig: TableInfo): String = {

    /**
      * 1. If incremental column is not present, the query would be: select ${tableConfig.cols} from ${tableConfig.tableName}
      * 2. If incremental column is present, we need to build the query using the date range and the join info..
      *    -- Some cases a date column is not present in the table being read. In that case, we need to join to another table
      *       using JoinInfo and build the query. In the case where we are joining we need to handle name conflicts in columns.
      *
      * Example:
      * select a.host_rx_id, a.host_order_id, a.requested_qty
      * from host_rx a, host_order ho
      * where a.host_rx_id = ho.host_order_id and a.received_date between (? , ?)
      *
      * 3. If sample % is provided, we need to use that to sample rows. Need to add sample (?) to the query
      * 4. If maxRecs is provided add that to the query  using something like ROWNUM < ${maxRecs}
      *
      */
    
    val select = rdd.map(str => {
				val separated = str.split(",", -1)
						val table= separated(0)
						val cols=separated(1).split("\\|", -1).mkString(",")
						val cols1 = separated(2)
						val cols2 = separated(3)

						if (cols.size>0 && cols1.size>0 && cols2.size>0 )
						{
							"select" + cols + "from" + table + "where" + cols1 + "=" + cols2 + ";"  //
						}
						else if (cols.size>0 && cols1.size>0 && cols2.size>0 )
						{
							"select" + cols + "from" + table + "where" + cols1 + ";"
						}
						else
						{
							"select" + cols + "from" + table + ";"
						}

			})
  }
}
