package com.esi.spark.hdfscompaction

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.log4j._
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.{Calendar, Date}
import java.text.SimpleDateFormat
import java.text.CalendarBuilder
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Row

class ReadCsv {
  
  Logger.getLogger("org").setLevel(Level.ERROR)
  val spark= SparkSession.builder().appName("compaction").enableHiveSupport().getOrCreate()
  var conf = new SparkConf().setAppName("Read CSV File").setMaster("local[*]")
	val sc = new SparkContext(conf)  //Creating SparkContext
  var calendar     =  Calendar.getInstance()
  val sdf          =  new SimpleDateFormat("yyyy-MM-dd:hh:mm")
  
  def minsAgo(mins: Int): String = {
      calendar.add(Calendar.MINUTE, -mins)
      sdf.format(calendar.getTime())
  }
  
   def hoursAgo(hours: Int): String = {
      calendar.add(Calendar.HOUR_OF_DAY, -hours)
      sdf.format(calendar.getTime())
  }
   
  def today(): String = {
    val calender = Calendar.getInstance()
    sdf.format(calender.getTime())
  }
  
	 def query (){

			val df = spark.read.format("csv").option("header", "true").load("hdfs:///tmp/ora_file1.csv")
			for (row <- df.rdd.collect){
          var location         = row.mkString(",").split(",")(0)
          var table_name       = row.mkString(",").split(",")(1)
          var Columns          = row.mkString(",").split(",")(2).split("\\|", -1).mkString(",")
          var condition_col    = row.mkString(",").split(",")(3)
          var fall_back_hrs    = row.mkString(",").split(",")(4)
          var set_off_mins     = row.mkString(",").split(",")(5)
          var src_join_column  = row.mkString(",").split(",")(6)
          var tgt_join_column  = row.mkString(",").split(",")(7)
          var join_table       = row.mkString(",").split(",")(8)
          var rec_count        = row.mkString(",").split(",")(9)
          var rec_percent      = row.mkString(",").split(",")(10)
          val endDateHour      = today()
          val startDateHour    = hoursAgo(fall_back_hrs.toInt) //hoursBetween
          val startDateHourMin = minsAgo(set_off_mins.toInt)//Minsback

          var qry=""
          
          if (condition_col.trim() != "null" && src_join_column.trim() != "null" && tgt_join_column.trim()!= "null" && join_table.trim()!= "null" )
          {
            qry = "select " + Columns + " from " + table_name +" , "+join_table+ " where "+table_name+"." + src_join_column + " = "+join_table+"." + tgt_join_column + " and " +table_name+"." +condition_col +" between  \'"+ startDateHourMin +"\' and \'"+endDateHour +"\' " //
          }
          else if (condition_col.trim()!= "null" && src_join_column.trim() == "null" && tgt_join_column.trim()== "null" && join_table.trim() == "null" )
          {
            qry = "select " + Columns + " from " + table_name + " where " + condition_col +" between  \'"+ startDateHourMin +"\' and \'"+endDateHour +"\' " //
          }
          else if (condition_col.trim()== "null" && src_join_column.trim()== "null" && tgt_join_column.trim()== "null" && join_table.trim()== "null")
          {
            qry = "select " + Columns + " from " + table_name
          }
          
          if ( qry.indexOf("where") >=0){
            if(rec_count!="null" && rec_count.toInt>=0){
              qry=qry+ " and rownum<="+rec_count
            } else if(rec_percent!="null" && rec_percent.toInt>=0) {
              qry=qry+ " and sample("+rec_percent +")"
            } 
          }else {
             if(rec_count!="null" && rec_count.toInt>=0){
              qry=qry+ " where rownum<="+rec_count
            } else if(rec_percent!="null" && rec_percent.toInt>=0) {
              qry=qry+ " where sample("+rec_percent +")"
            }             
          } 
          println (qry)
          calendar     =  Calendar.getInstance()

     }

	 }		
	 
}
