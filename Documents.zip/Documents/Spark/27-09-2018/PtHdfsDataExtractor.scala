package com.esi.dpe.pt.validation

import org.apache.spark.sql.SparkSession

object PTHdfsDataExtractor {

  /**
    * Extracts
    */
  def extractData (spark:SparkSession, tableConfig:TableConfig, hdfsBasePath:String) = {
    /**
      * Use the hdfs base path, location, table, current time and lookbackHours to determine folders to read.
      * Base path should be read from config. Example Base Path: /datahub/pt_rpt/landing.
      * Sample folder structure: /datahub/pt_rpt/landing/MGPH.ORD_RX/70/2018_09_05/2018_09_05_23/1536206361195/part-00000-895d4c1f-f554-40bf-bf82-ace1bbad0d39.json
      *    -- where 70 is the location and MGPH.ORD_RX is the table name.
      *    -- Newly added files are at this level /datahub/pt_rpt/landing/<TABLE>/<LOCATION>/*/*/*/*
      *    -- Compacted files are under: /datahub/pt_rpt/landing/<TABLE>/<LOCATION>/*/*
      * If lookbackHours are not provided, read all JSON files under /datahub/pt_rpt/landing/<TABLE>/<LOCATION>/.
      *   We need to read both compacted and un-compacted files.
      * If lookbackHours is provided,
      */
  }
}
