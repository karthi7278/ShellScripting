import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.log4j

object ReadCsv {
	def main(args:Array[String]):Unit = {
	
	Logger.getLogger("org).setLevel(Level.ERROR)
	
	var conf = new SparkConf().setAppName("Read CSV File").setMaster("local[*]")
	val sc = new SparkContext(conf)  //Creating SparkContext
	val rdd = sc.textFile("Give your CSV path here") //Reading CSV file from the given path
	val select = rdd.map(str => {
		val separated = str.split(",", -1)
			val table= separated(0)
			val cols=separated(1).split("\\|", -1).mkString(",")
			val cols1 = separated(2)
			val cols2 = separated(3)
			
			if (cols.size>0 && cols1.size>0 && cols2.size>0 )
				{
					"select" + cols + "from" + table + "where" + cols1 + "=" + cols2 + ";"  //
				}
			else if (cols.size>0 && cols1.size>0 && cols2.size>0 )
				{
					"select" + cols + "from" + table + "where" + cols1 + ";"
				}
			else
			{
					"select" + cols + "from" + table + ";"
			}
		
							})
		
			select.foreach(println(_))				
			
				}
				}
		