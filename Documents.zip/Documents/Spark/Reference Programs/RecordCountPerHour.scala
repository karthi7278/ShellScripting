package com.esi.rpt.util
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.spark.sql.SparkSession
import org.apache.hadoop.fs.PathFilter
import scala.collection.mutable.ListBuffer

object RecordCountPerHour {
	def main(args: Array[String]) {
		if (args.length !=3) {
			System.err.println(s"""
					|Usage: RecordCountPerHour <inPutPath> <date> <ouput_path>
					""".stripMargin)
			System.exit(1)
		}

		val inputPath=args{0}
		val inputDate=args{1}
		val outputPath=args{2}



		val spark: SparkSession = SparkSession.builder().appName("Record Count Per Hour for PT table ")
				.config("SPARK_MAJOR_VERSION", "2").enableHiveSupport().getOrCreate()

				val path = new Path(inputPath)
				val fs:FileSystem = path.getFileSystem(spark.sparkContext.hadoopConfiguration)
				var recCount = new ListBuffer[String]()
				//

				/* class TmpFileFilter  extends PathFilter {
  override def accept(path : Path): Boolean = path.getName.endsWith(inputDate)
} 

val s2=fs.listStatus(path).map( x => fs.listStatus(x.getPath, new TmpFileFilter()))
				 */


				val dateLevel = fs.listStatus(path).map(x=>fs.listStatus(x.getPath)).flatMap(x => x)

				dateLevel.foreach(x => {
					if(x.getPath.toString().contains(inputDate))  
						//got path for input date
						fs.listStatus(x.getPath).map(x=>{
							val x1=x.getPath.toString()
									val count=spark.read.json(x1+"/*/*").count() 
									println(count + " ==> "+x1)
									recCount+=	x1.slice(x1.indexOfSlice("landing")+8,x1.length).replaceAll("/",",")+","+count
						})
				})
				
				if(recCount.length>0) 
				  spark.sparkContext.parallelize(recCount).coalesce(1).saveAsTextFile(outputPath)

	}
}