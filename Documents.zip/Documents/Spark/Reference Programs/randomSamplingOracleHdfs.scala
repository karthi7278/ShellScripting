
/* The program is for comparing a random sample of data from oracle to HDFS.
 * 
 * It takes the random percentage sample from Oracle and then finds the latest data as per the primary keys from HDFS.
 * After getting both the datasets we will do a comparison and send an email if there are records with discrepancy. 
 * 
 */




package com.esi.rpt.util

import java.util.Properties

import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.lit
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col, lit, when}
import com.esi.rpt.streams.SendEmail

import com.typesafe.config.ConfigFactory
import java.text.SimpleDateFormat

object randomSamplingOracleHdfs 
{
  
  def main(args:Array[String]):Unit= 
    
  {
   
  //  Class.forName("oracle.jdbc.OracleDriver");
    
    val sparkConf = new SparkConf().setAppName("randomSampling")
    
    val spark = SparkSession.builder.config(sparkConf).getOrCreate()
    
    
    val connection_file = args{0}
    val pharmacy_location = args{1}
    val table_name = args{2}
    val primary_key = args{3}
    val ordering_column = args{4}
    val sample_percentage = args{5}
    val hdfsdatapath = args{6}
    val columns = args{7}
    val boolean_columns = args{8}
    val max_records =args{9}
    
    val connection_Detail = spark.read.json(connection_file).where("pharmacy_location =="+pharmacy_location)
 
    println("Total count is "+connection_Detail.count())
    
    val username = connection_Detail.select("USER").first.mkString
    
 //   println("*******************************************************************"+username)
    
    val password = connection_Detail.select("PASS").first.mkString
 //   println("*******************************************************************"+password)
    val conn_string = connection_Detail.select("DBURL").first.mkString
    
 //   println("*******************************************************************"+conn_string)
    
    val driver = connection_Detail.select("dbClass").first.mkString
    
 //   println("*******************************************************************"+conn_string)
    
    
   val conf= ConfigFactory.load("env.conf")
    
//import java.util.Properties
      val connectionProperties = new Properties()
connectionProperties.put("user", username)
connectionProperties.put("password", password)
connectionProperties.put("driver",driver)


try
    {
  
  val query = "(select  "+ columns +"  from "+ table_name +" sample("+sample_percentage+") where rownum <" + max_records +")"
  
  println(query)
  
  val df_from_oracle = spark.read.jdbc(url=conn_string, table =query, properties =connectionProperties).persist(StorageLevel.MEMORY_ONLY)
                                 .withColumn("pharmacy_location", lit(args{1}))
                                 .withColumn("SCHEMA_TABLE_NAME", lit(table_name))
  
  df_from_oracle.show()                               
  df_from_oracle.createOrReplaceTempView("ORACLE_DATA")
  
 // val df_from_hdfs = spark.read.json(conf.getString("hdfs.streamoutpath")+"/"+table_name+"/"+pharmacy_location+"/*/*/*/*").persist(StorageLevel.MEMORY_ONLY)
  
  Thread.sleep(60000)
  
  val df_from_hdfs = spark.read.json(hdfsdatapath).persist(StorageLevel.MEMORY_ONLY)
  
  df_from_hdfs.createOrReplaceTempView("hdfs_Data")
  
  // Fetching latest record for each primary key
  
  val Latest_record_for_each_primary_key = spark.sql("select * from (select t.*, row_number() over (partition by message.data." + primary_key + " order by message.headers." + ordering_column + "  desc) as rn  from hdfs_Data t) where rn =1").persist(StorageLevel.MEMORY_ONLY)
  
 // Latest_record_for_each_primary_key.select("message.headers.*").show()
  
  val Latest_record_for_each_primary_key_data = Latest_record_for_each_primary_key.select("message.data.*")
  
  Latest_record_for_each_primary_key_data.show()
 
  Latest_record_for_each_primary_key_data.createOrReplaceTempView("HDFS_FILTERED_DATA1")
  
  
  val HDFS_Columns_for_comparison = spark.sql("select "+ columns + " from HDFS_FILTERED_DATA1")
  
  HDFS_Columns_for_comparison.createOrReplaceTempView("HDFS_FILTERED_DATA")
  
//val Required_keys_from_hdfs = Latest_record_for_each_primary_key_data.join(df_from_oracle,Latest_record_for_each_primary_key.col("message.data."+primary_key)===df_from_oracle.col(primary_key),"left")//.where(primary_key+" is not null")
  
  val query_2 =  "select h.* from HDFS_FILTERED_DATA h, ORACLE_DATA o where h."+primary_key+"=o."+primary_key
 
  println(query_2)
  val Required_keys_from_hdfs = spark.sql("select h.* from HDFS_FILTERED_DATA h, ORACLE_DATA o where h."+primary_key+"=o."+primary_key).persist(StorageLevel.MEMORY_ONLY) // .drop("pharmacy_location").drop("SCHEMA_TABLE_NAME")
 
 println("-------oracle table---")
  df_from_oracle.show()
  println("-------latest record---")
  Latest_record_for_each_primary_key_data.show()
  println("---required keys----")
  Required_keys_from_hdfs.show()
  
  
   val b_value = "  true"

   
 /* Tail recursion method to convert the Boolean values for columns to 1 and 0
  * True =1
  * false = 0 
  */
   
   
   def Change_boolean_columns(df:DataFrame,column_names:List[String]):DataFrame=
  {
    val column_name= column_names.head
    
    println(column_name)
    
    println("original df")
    df.show()
    
  //  val df1= df.withColumn("new_column",when(col(column_name)===lit(b_value),"1").otherwise("0")).drop(column_name).withColumnRenamed("new_column",column_name)
    
    val df1= df.withColumn("new_column",when(col(column_name).contains("true"),"1").otherwise("0")).drop(column_name).withColumnRenamed("new_column",column_name)
    
    println("after processing")
    
    df1.show
   if( column_names.size > 1)
   {
   Change_boolean_columns(df1,column_names.tail)
   }
    
   else
   {
    println("just before returning")
    df1.show()
   
    return df1 
   }
  }
  
  var oracle_data_with_boolean_handled = df_from_oracle
  
  if(!boolean_columns.contains("no_boolean"))
  {
    println("Boolean column provided")
    oracle_data_with_boolean_handled = Change_boolean_columns(df_from_oracle,boolean_columns.split(",").toList)
  }
  

  println("oracle data after booleans converted")
  
  oracle_data_with_boolean_handled.show()
  
  /* Getting the alphabetically ordered list of columns from the data fetched in Oracle
   * 
   */
  
  val cols = Required_keys_from_hdfs.columns.sorted.map(str=>col(str))
  
  /*
   * selecting the columns which are ordered into another dataframe.
   */
  
  val oracle_source_data_reordered_cols = oracle_data_with_boolean_handled.select(cols:_*) 
  
 // oracle_source_data_reordered_cols.printSchema()
  
  val HDFS_destination_data = Required_keys_from_hdfs.select(cols:_*)
  
 // HDFS_destination_data.printSchema()
  
  /*
   * Converting the data type of all columns to string so that comparison can be done
   */
  val oracle_source_data_reordered_cols_string_type = oracle_source_data_reordered_cols.select(oracle_source_data_reordered_cols.columns.map(c=>col(c).cast("string")):_*)
  val HDFS_destination_data_string_type = HDFS_destination_data.select(HDFS_destination_data.columns.map(c=>col(c).cast("string")):_*)
  
  oracle_source_data_reordered_cols_string_type.show(false)
  
  println("SAMPLE COUNT FETCHED FROM ORACLE --- "+oracle_source_data_reordered_cols_string_type.count())
  
  HDFS_destination_data_string_type.show(false)
  
  println("HDFS DATA COUNT ---- "+HDFS_destination_data_string_type.count())
  
  val date_today = new SimpleDateFormat("yyyy_MM_dd");
  val date_today_hour = new SimpleDateFormat("yyyy_MM_dd_HH");
  val PATH_SEPERATOR = "/";
  val se = new SendEmail
  /*
   * Check if the data from source and HDFS has same count or not
   * 
   */
  
  
//  if(oracle_source_data_reordered_cols_string_type.count()>HDFS_destination_data_string_type.count())
//  {
//    
//    val Records_from_oracle_not_in_hdfs= oracle_source_data_reordered_cols_string_type.except(HDFS_destination_data_string_type)
//    val path_to_missing_data = "/datahub/pt_rpt/landing/RandomSampling_Result/Missing_oracle_Data"++PATH_SEPERATOR + table_name + PATH_SEPERATOR + args{1}+ PATH_SEPERATOR+ date_today.format(System.currentTimeMillis())+ PATH_SEPERATOR + date_today_hour.format(System.currentTimeMillis()) + PATH_SEPERATOR + System.currentTimeMillis()
//      
//    Records_from_oracle_not_in_hdfs.coalesce(1).write.json(path_to_missing_data)
//    
//    se.sendMail("vjoshi@express-scripts.com", "Possible missing data for "+table_name,"Here is the path to the Data    "+path_to_missing_data)
//    se.sendMail("snagarajan@express-scripts.com", "Possible missing data for"+table_name,"Here is the path to the Data    "+path_to_missing_data)
//    
//    
//  }
//  
//  else
//  {
    
  
  /*
   * Comparing the two dataframes to throw all the rows where any one of the column has discrepancy
   */
  val Records_having_discrepencies = HDFS_destination_data_string_type.except(oracle_source_data_reordered_cols_string_type)
 
  
//  oracle_source_data_reordered_cols.show()
//  HDFS_destination_data.show()
//  
  Records_having_discrepencies.show()

  
  //Send email when there are mismatched counts
  
  if(Records_having_discrepencies.count>0)
  {
    
    val path = "/datahub/pt_rpt/landing/RandomSampling_Result/Unsuccessful_run"+PATH_SEPERATOR + table_name + PATH_SEPERATOR + args{1}+ PATH_SEPERATOR+ date_today.format(System.currentTimeMillis())+ PATH_SEPERATOR +"unmatched_records/" +date_today_hour.format(System.currentTimeMillis()) 
    val path_to_oracle_sample = "/datahub/pt_rpt/landing/RandomSampling_Result/Unsuccessful_run"+PATH_SEPERATOR + table_name + PATH_SEPERATOR + args{1}+ PATH_SEPERATOR+ date_today.format(System.currentTimeMillis())+ PATH_SEPERATOR +"Oracle_Sample/" +date_today_hour.format(System.currentTimeMillis())  
    val path_to_hdfs_sample = "/datahub/pt_rpt/landing/RandomSampling_Result/Unsuccessful_run"+PATH_SEPERATOR + table_name + PATH_SEPERATOR + args{1}+ PATH_SEPERATOR+ date_today.format(System.currentTimeMillis())+ PATH_SEPERATOR +"HDFS_Sample/"+ date_today_hour.format(System.currentTimeMillis())  
      
    
    Records_having_discrepencies.coalesce(1).write.json(path)
       
    val failure_email_content = """ Number of unmatched records    """ + Records_having_discrepencies.count.toString() + """
                                    | Here is the path to the Data   """ +path.replace("|", "\n") 
    
    se.sendMail("vjoshi@express-scripts.com", "Random sampling for "+table_name+" failed ",failure_email_content)
    se.sendMail("snagarajan@express-scripts.com", "Random sampling for "+table_name+" failed ",failure_email_content)

  }
  
  else
  {
  
    val path_to_oracle_sample= "/datahub/pt_rpt/landing/RandomSampling_Result/Successful_run"+PATH_SEPERATOR + table_name+"_Oracle" + PATH_SEPERATOR + args{1}+ PATH_SEPERATOR+ date_today.format(System.currentTimeMillis())+ PATH_SEPERATOR + date_today_hour.format(System.currentTimeMillis()) + PATH_SEPERATOR + System.currentTimeMillis()
    val path_to_hdfS_data= "/datahub/pt_rpt/landing/RandomSampling_Result/Successful_run"+PATH_SEPERATOR + table_name+"_HDFS" + PATH_SEPERATOR + args{1}+ PATH_SEPERATOR+ date_today.format(System.currentTimeMillis())+ PATH_SEPERATOR + date_today_hour.format(System.currentTimeMillis()) + PATH_SEPERATOR + System.currentTimeMillis()
    
    oracle_source_data_reordered_cols_string_type.coalesce(1).write.json(path_to_oracle_sample)
    HDFS_destination_data_string_type.coalesce(1).write.json(path_to_hdfS_data)
    
    val email_content = """No discrepancy in the sample that was matched and Data samples can be found at Oracle _sample -- #"""+ path_to_oracle_sample + "HDFS path-#"+path_to_hdfS_data +
                           """| Oracle count =  """ + oracle_source_data_reordered_cols_string_type.count().toString() + "#"
                           """HDFS Count =  """ + HDFS_destination_data_string_type.count().toString().stripMargin.replace("#", "\n")  
                           
    
    se.sendMail("vjoshi@express-scripts.com", "Random sampling for "+table_name+" was successful ",email_content)
   // se.sendMail("vjoshi@express-scripts.com", "Random sampling for "+table_name+" was successful ",email_content)
 
  }

  }
    //}

  catch
  {
     case e:Throwable => e.printStackTrace()
  }
  }
  
  
}