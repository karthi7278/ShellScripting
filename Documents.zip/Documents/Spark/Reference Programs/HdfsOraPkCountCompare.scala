package com.esi.rpt.util

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import com.typesafe.config.ConfigFactory
import java.text.SimpleDateFormat

/*
 * This program will be used to compare Hdfs and count for WIP,Short and Long tables
 */
object HdfsOraPkCountCompare {
  
  def main(args: Array[String]): Unit = {

    if(args.length != 5 ) {
      println(" Invalid number of input arguments. Current length "+args.length )
      println("connection.conf DBName Wip_Short_Long_table PrimaryKey  hdfs_path")
    
      return

    }
    
    // Conn DBName Wip,Short,Long_Table PK 
    
    /*
     1. Get Hdfs count
     		Get count from both level 2 and level 4
     		Get count from level 4 only 
     2. Connection creation
     3. Create union all
     4. Get Oracle count
     5. Write hdfs and oracle count to file ( RunDate,input_tables,Ora count,hdfs count,status) 
     
     Todo :     
     Number format for oracle count -- Done
     Union all for only available tables in oracle side using ora dict  --Done
     Multi column count in HDFS and Oracle-- Done
     Exception handingling --DONE
     change script with list of columns used for index 
     hive table permission to pt team
     
     */
   
    val connection=args{0}
    val dbName="DBNAME='"+args{1}+"'"
    val iTables=args{2}
    val iPk=args{3}
    val hdfsLogPath=args{4}
    val tables=iTables.split(",")
    val toDay = new SimpleDateFormat("yyyy_MM_dd").format(System.currentTimeMillis())  
      
    val spark: SparkSession = SparkSession.builder()
      .appName("HdfsOraPkCountCompare")
      .config("SPARK_MAJOR_VERSION", "2")
      .enableHiveSupport()
      .getOrCreate()
      
      try {
      
    // 2. Connection creation
     val con=spark.read.json(connection).filter(dbName)
    val dburl=con.select("DBURL").collect().mkString("").replace("[", "").replace("]", "")
    val userName=con.select("USER").collect().mkString("").replace("[", "").replace("]", "")
    val pwd=con.select("PASS").collect().mkString("").replace("[", "").replace("]", "")
    val dbClass=con.select("dbClass").collect().mkString("").replace("[", "").replace("]", "")
    val pl=con.select("PHARMACY_LOCATION").collect().mkString("").replace("[", "").replace("]", "")
    var log=args{1}+"^"+toDay+"^"+iTables+"^"+iPk
    var oraCount=0d
    var hdfsCount=0d
   
    //get only available table list from oracle
    val query="select  concat(concat(owner,'.'),table_name) table_name from all_tables where concat(concat(owner,'.'),table_name)  in ( " + "'"+iTables.replace(",","','")+"'"+" )"
    println("Query for finding only required table "+ query)
    val oraTables=spark.read.format("jdbc").option("url", dburl).option("driver", dbClass).option("dbtable", "("+ query+")").option("user", userName).option("password", pwd).load()
    val oraTable=oraTables.rdd.map( x=> x(0)).collect()
    
    try {
    
    // 3. Create query to get the count from all required table from oracle
    val header="select count(*) as pk from ( select distinct "+iPk+"  from ( " 
    val fooder =" ) a ) a "
    var selectStmt=" select distinct "+iPk+" from  " + oraTable{0}
    if(tables.length==2 ) { //Only short or long
      selectStmt=selectStmt + " union select distinct "+iPk+"  from "+oraTable{1} 
     }else if( tables.length ==3 ) { //Both short and long tables
      selectStmt=selectStmt + " union select distinct "+iPk+"  from "+oraTable{1}  + " union select distinct "+iPk+"  from "+oraTable{2}
    }    
    val query=header +selectStmt +fooder 
     println("Query for finding count"+ query)
    // 4. Get Oracle count     
    val oracleRecords1 = spark.read.format("jdbc").option("url", dburl).option("driver", dbClass).option("dbtable", "("+ query+")").option("user", userName).option("password", pwd).load()
    oraCount=oracleRecords1.select("pk").collect(){0}.mkString("").replace("[", "").replace("]", "").toDouble
    log=log+"^"+oraCount 
    println("count "+ oraCount)
    
   }  catch {
        case e: Exception => 
          e.printStackTrace()
          
          println(e.getMessage)
          log=log+"^"+e.getMessage 
        
      }
    
 
   val hdfsPath = ConfigFactory.load("env.conf").getString("hdfs.streamoutpath")+"/"+tables{0}+"/"+pl+"/*/*" 
   val pk = iPk.split(",")
    
    try {
     // 1. Get Hdfs count  for one key column or multiple key column (_* => Smooch operator in scala)
      // Get count from both level 2 and level 4  
    hdfsCount= spark.read.json(hdfsPath).select("message.data.*").select(pk{0},pk:_*).distinct()
    .union(spark.read.json(hdfsPath+"/*/*").select("message.data.*").select(pk{0},pk:_*).distinct()).distinct().count()
    log=log+"^"+hdfsCount
      
    }  catch {
        case e: Exception => 
            println(e.getMessage)
            println("error when we check for both level ")
          try {
            // Get count only from level 4
            hdfsCount= spark.read.json(hdfsPath+"/*/*").select("message.data.*").select(pk{0},pk:_*).distinct().count()
            log=log+"^"+hdfsCount
            
          } catch {
        case e: Exception => 
          
          e.printStackTrace()
          print("error while commiting the offset")
          println(e.getMessage)
          log=log+"^"+e.getMessage
          }
         
        
      }
    
     
    // 5. Write hdfs and oracle count to file ( RunDate,input_tables,Ora count,hdfs count,Confident level(%))     
    if(hdfsCount > oraCount) {
      log=log+ "^100"     
    }else if (hdfsCount!=0 && oraCount!=0 )  {
     
      log=log+  "^"+ hdfsCount/oraCount*100      
    } else {
      log=log+  "^"+"Oracle or HDFS has 0 values"
      
    }
    
// Seq(log).toDF( "MESSAGE").coalesce(1).write.format("csv").save("")
    spark.sparkContext.parallelize(Seq(log)).coalesce(1).saveAsTextFile(hdfsLogPath+tables{0}+"_"+toDay+"_"+ System.currentTimeMillis() )
    
      } catch {
        case e: Exception => 
          e.printStackTrace()
          print("error while commiting the offset")
          println(e.getMessage)
          spark.sparkContext.parallelize(Seq(args{1}+"^"+toDay+"^"+iTables+"^"+iPk+"^0^0^"+e.getMessage)).coalesce(1).saveAsTextFile("/user/hdpsparkprd/HdfsOraPkCountCompare/"+tables{0}+"_"+toDay+"_"+ System.currentTimeMillis() )
        
      }
    
  }
  
}
