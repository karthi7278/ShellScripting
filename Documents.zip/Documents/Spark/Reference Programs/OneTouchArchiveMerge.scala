package com.esi.rpt.util



import java.text.SimpleDateFormat
import java.util.Calendar
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import com.typesafe.config.ConfigFactory



     /** This class used to marge the archive table 
  	       1. Get Wip table first loaded date
  	       2. Get arch table data and Move arch data to new wip date path
  	       3. Write result
  	       */

object OneTouchArchiveMerge {
  
  
  	def main(args:Array[String]):Unit=
		{
  	  
  	  
  	      if(args.length != 5) {
		      println("Input argument ==>  WIP_TABLE_NAME ARCH_TBALE_NAME PHARMACY_LOCATION NUMBER_OF_DAY_BEFORE OUTPUT_FILE")
		      
		      return
		    }
  	      val iWipTable=args{0}
  	      val iArchTable=args{1}
  	      val iPharmacyLocation=args{2}
  	      val n= args{3}.toInt
  	      val outputPath=args{4}
  	      
  	      	val sparkConf = new SparkConf().setAppName("Merge_ARCH_TO_WIP")

				val spark = SparkSession.builder.config(sparkConf).enableHiveSupport().getOrCreate() 
				val formatter = new SimpleDateFormat("yyyy_MM_dd")
		
				val PATH_SEPERATOR = "/" 
				
				val landingHome= ConfigFactory.load("env.conf").getString("hdfs.streamoutpath") 
				val archTablePath= landingHome + PATH_SEPERATOR + iArchTable + PATH_SEPERATOR+iPharmacyLocation+"/*/*/*/*"
				val wipTablePath_Pl=landingHome+PATH_SEPERATOR+iWipTable + PATH_SEPERATOR+ iPharmacyLocation + PATH_SEPERATOR
				
				//1. Get Wip table first loaded date
				//val wipTablePath_Pl="/datahub/pt_rpt/landing/MGPH.ACCUMULATOR/56/"
				
				val files = FileSystem.get( spark.sparkContext.hadoopConfiguration ).listStatus(new Path(wipTablePath_Pl)).map(path => path.getPath.getName).sorted		
				
				// logic	for subracting 		
				val dateAux = Calendar.getInstance()
        dateAux.setTime(formatter.parse(files(0)))
        dateAux.add(Calendar.DATE, -n)
        val dateForArchiveTable= formatter.format(dateAux.getTime())
				
        val wipTablePath=wipTablePath_Pl+PATH_SEPERATOR +dateForArchiveTable +PATH_SEPERATOR+ dateForArchiveTable +"_20"+PATH_SEPERATOR+System.currentTimeMillis()+PATH_SEPERATOR
	
				
				// 2. Get arch table data        
         spark.read.json(archTablePath).coalesce(1).write.json( wipTablePath ) 
        
         // 3. Write the log info into hdfs 
         val log =iPharmacyLocation+"^"+formatter.format(System.currentTimeMillis()) + "^"+ archTablePath+"^"+wipTablePath         
         spark.sparkContext.parallelize(Seq(log)).coalesce(1).saveAsTextFile(outputPath+PATH_SEPERATOR +iWipTable+"_"+iArchTable+"_"+ System.currentTimeMillis() )
         	      
		}
}